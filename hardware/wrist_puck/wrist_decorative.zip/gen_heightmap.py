import numpy as np
from PIL import Image, ImageDraw, ImageFilter
from scipy.ndimage import gaussian_filter

W = H = 240
cx, cy = W/2, H/2
ys, xs = np.mgrid[0:H, 0:W]
xs_c = xs - cx
ys_c = ys - cy
r = np.sqrt(xs_c**2 + ys_c**2)
theta = np.arctan2(ys_c, xs_c)

R = min(W, H) / 2 * 0.97

height = np.zeros((H, W), dtype=np.float64)

# ---- Layer 1: outer border, dense recursive banding (Piranesi/Escher feel) ----
# multiple frequencies riding on top of each other, spacing tightens toward
# the outer edge like an engraved architectural cornice
border_mask = (r < R) & (r > R * 0.70)
band = (
    0.45 * np.sin(r * 0.55) +
    0.30 * np.sin(r * 1.35 + theta * 5) +
    0.20 * np.sin(theta * 32) +
    0.15 * np.sin(r * 0.9 - theta * 3)
)
height = np.where(border_mask, 0.55 + 0.45 * band, height)

# ---- Layer 2: mid recursive ring -- period compresses as radius shrinks,
# a spiral-labyrinth motif that reads as "layers within layers" ----
mid_mask = (r < R * 0.70) & (r > R * 0.34)
recursive = np.sin(26 * np.log(r + 1) + theta * 9) * 0.5 + \
            np.sin(theta * 14 - r * 0.15) * 0.5
height = np.where(mid_mask, 0.5 + 0.4 * recursive, height)

# thin engraved groove separating border / mid / center zones, for a
# crisp architectural line rather than a soft blend everywhere
for ring_r, ring_w, ring_depth in [(R*0.70, 3, -0.35), (R*0.34, 3, -0.35)]:
    groove = (np.abs(r - ring_r) < ring_w)
    height = np.where(groove, height + ring_depth, height)

# ---- Layer 3: central pastoral scene -- small robotic creature (echoing
# the Pollen Pod / Perch Pod family) standing among a few coral/vine
# mounds, raised as the foreground layer ----
scene = Image.new('L', (W, H), 0)
draw = ImageDraw.Draw(scene)

bx, by = int(cx + 15), int(cy + 25)   # creature position, slightly off-center

# coral/vine mounds first (background of the scene, lower relief)
for (mx, my, mr) in [(-95, 40, 26), (85, 65, 20), (-70, -55, 16), (100, -30, 14)]:
    draw.ellipse([cx+mx-mr, cy+my-mr, cx+mx+mr, cy+my+mr], fill=140)
# small "vine" tendrils connecting mounds -- simple curved strokes
draw.line([(cx-95+26, cy+40), (bx-30, by)], fill=110, width=6)
draw.line([(cx+85-20, cy+65), (bx+40, by+10)], fill=110, width=6)

# creature: capsule body (Pollen Pod egg-shape), small head, thin legs --
# same silhouette language as the reference diagram, simplified
draw.ellipse([bx-42, by-26, bx+42, by+26], fill=255)          # body
draw.ellipse([bx+28, by-42, bx+64, by-8], fill=250)            # head
draw.ellipse([bx+45, by-33, bx+52, by-26], fill=0)              # eye (recessed)
for lx in (-26, -8, 12, 30):
    draw.rectangle([bx+lx-3, by+18, bx+lx+3, by+50], fill=210)  # legs
# small perch/branch under the creature's feet
draw.line([(bx-40, by+50), (bx+40, by+50)], fill=170, width=5)

scene_arr = np.array(scene, dtype=np.float64) / 255.0
scene_arr = gaussian_filter(scene_arr, sigma=1.0)

central_mask = r < R * 0.34
# center zone starts from a calm low base, then the scene rises out of it
height = np.where(central_mask, 0.15, height)
height = height + np.where(central_mask, scene_arr * 0.85, 0)

# ---- final smoothing pass -- continuous gradients hold shape better in
# raking light than hard steps, per the cameo relief comparison ----
height = gaussian_filter(height, sigma=0.8)

# normalize
height -= height.min()
height /= height.max()

arr16 = (height * 65535).astype(np.uint16)
Image.fromarray(arr16, mode='I;16').save('lid_heightmap.png')

# also save an 8-bit preview for quick visual inspection
Image.fromarray((height*255).astype(np.uint8), mode='L').save('lid_heightmap_preview.png')
print("done", W, H)
